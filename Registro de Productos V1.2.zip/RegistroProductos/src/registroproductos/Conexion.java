
package registroproductos;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Conexion {
    
    public Connection conectar(){
        Connection con=null;
        String url= "jdbc:mysql://localhost:3306/otari-base";
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection(url, "root", "n0m3l0");
            System.out.println("En linea");
        } catch(Exception ex){
            System.out.println("Error para conectar a la base D:");
        }
        return con;
    }
    
    public ResultSet visualizarMenu(){
        Connection con= conectar();
        ResultSet rs=null;
        try{
            PreparedStatement ps=con.prepareStatement("select * from Menu");
            rs=ps.executeQuery();
        }catch(Exception ex){
            System.out.println("Error de consulta");
        }
        return rs;
    }
     public ResultSet visualizarDeco(){
        Connection con= conectar();
        ResultSet rs=null;
        try{
            PreparedStatement ps=con.prepareStatement("select * from Decoracion");
            rs=ps.executeQuery();
        }catch(Exception ex){
            System.out.println("Error de consulta");
        }
        return rs;
    }
      public ResultSet visualizarMusica(){
        Connection con= conectar();
        ResultSet rs=null;
        try{
            PreparedStatement ps=con.prepareStatement("select * from Musica");
            rs=ps.executeQuery();
        }catch(Exception ex){
            System.out.println("Error de consulta");
        }
        return rs;
    }
    
    public void guardar_imagenMenu(String ruta, String principal, String entrada, String postre, String bebidas){
        Connection con=conectar();
        String insert ="insert into Menu(entrada, principal, postre, bebidas, foto) values (?,?,?,?,?)";
        FileInputStream fi=null;
        PreparedStatement ps=null;
        try{
            File file= new File(ruta);
            fi= new FileInputStream(file);
            
            ps=con.prepareStatement(insert);
            ps.setString(1, entrada);
            ps.setString(2, principal);
            ps.setString(3, postre);
            ps.setString(4, bebidas);
            ps.setBinaryStream(5, fi);
            ps.executeUpdate();
        }catch(Exception ex){
            System.out.println("Error al guardar");
        }
    }
    public void guardar_Musica( String genero, String personal){
        Connection con=conectar();
        String insert ="insert into Musica(genero, personal) values (?,?)";
        
        PreparedStatement ps=null;
        try{
            
            ps=con.prepareStatement(insert);
            ps.setString(1, genero);
            ps.setString(2, personal);
            ps.executeUpdate();
        }catch(Exception ex){
            System.out.println("Error al guardar");
        }
    }
     public void guardarDecoracion(String ruta,String nombre, float precio, String descripcion){
        Connection con=conectar();
        String insert ="insert into Decoracion(nombre, precio, descripcion, foto) values (?,?,?,?)";
        FileInputStream fi=null;
        PreparedStatement ps=null;
        try{
            File file= new File(ruta);
            fi= new FileInputStream(file);
            
            ps=con.prepareStatement(insert);
            ps.setString(1, nombre);
            ps.setFloat(2, precio);
            ps.setString(3, descripcion);
            ps.setBinaryStream(5, fi);
            ps.executeUpdate();
        }catch(Exception ex){
            System.out.println("Error al guardar");
        }
    }
}


