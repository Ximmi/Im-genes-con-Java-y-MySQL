/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registroproductos;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class VerTabla {
     public void visualizar_tabla(JTable tabla){
        Conexion conn= new Conexion();
        Connection con= conn.conectar();
        ResultSet rs= conn.visualizarMenu();
        
        //Instanciamos la clase que permite visualizar el JLabel de las Imagenes
        tabla.setDefaultRenderer(Object.class, new TablaImg());
        
        DefaultTableModel dt= new DefaultTableModel();
        dt.addColumn("Entrada");
        dt.addColumn("Principal");
        dt.addColumn("Postre");
        dt.addColumn("Bebidas");
        dt.addColumn("Foto");
        try{
            while(rs.next()){
                Object[] fila= new Object[5];
                fila[0]= rs.getObject(2);
                fila[1]=rs.getObject(3);
                fila[2]=rs.getObject(4);
                fila[3]=rs.getObject(5);
                Blob blob= rs.getBlob(6);
                //del blob en bytes transformamos desde la base a imagen :3
                byte[] data = blob.getBytes(1,(int)blob.length()); 
                BufferedImage img=null;
                try{
                    //Lee la imagen y lo convierte a ImageIO
                    img=ImageIO.read(new ByteArrayInputStream(data));
                }catch(Exception ex){
                    System.out.println("No leyó la imagen u.u");
                }
                ImageIcon icono= new ImageIcon(img);
                //para que la imagen sea mostrada en la tabla es necesario un JLabel
                fila[4]= new JLabel(icono);
                dt.addRow(fila);
            }
            
            tabla.setModel(dt);
            tabla.setRowHeight(64);
        }catch(Exception ex){
            System.out.println("Error al ver tabla T^T");
        }
    }
}
